<?php
	include_once 'header.php'; /* to include header code here*/
?>
<section class="main-container">
	<div class="main-wrapper">
		<h2 style="text-align: left;">HungryRiders</h2>
		<h3><strong><em>"Food is the<br> ingredient that <br>binds us together"</em></strong></h3>

		<div class="imagechange" >
			<img src="projectpics\coverphoto.webp" width="100%" height="95%" >
		</div>
		<?php
			/* if session variable is set inside the website*/
			//you use this same "isset()" function,to change any content on any page, when a user is logged in.
			if (isset($_SESSION['u_id'])) {
					//echo "You are logged in!";
					$user_id=$_SESSION['u_id'];
					echo '<form class="signup-form" action="menu.php" method="POST" style="float:left">
					<button type="submit" name="menu" value=' .$user_id.'>Menu</button></form>';
				}

		?>
	</div>
</section>
<?php
	include_once 'footer.php'; /*to include footer code here*/
?>

