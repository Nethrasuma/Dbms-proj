<?php
	include_once 'headerdelivery.php';

	$servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "loginsystem";

	// Create connection
	$conn = new mysqli($servername, $username, $password, $dbname);
	function vieworders($date,$flag)
	{
		$servername = "localhost";
		$username = "root";
		$password = "";
		$dbname = "loginsystem";
		// Create connection
		$conn = new mysqli($servername, $username, $password, $dbname);
		$dpid=$_SESSION['d_pid'];
		if($flag==1)
		{
			$sql="select orderdate,orderno,status from orders where deliverypid='$dpid'";
		}
		else
			$sql="select orderdate,orderno,status from orders where deliverypid='$dpid' and orderdate='$date'";

		$result=mysqli_query($conn,$sql);
		$resultCheck = mysqli_num_rows($result);?>
		<center style='font-size:30px;font-style:italic'><?php
		if($resultCheck<1)
			echo "<br>No Orders delivered";
		else{
			?>
		<br>
		
		<table  width="500px" height="150px" border="2px" cellpadding="20px" cellspacing="5px" style="background-color: white;text-align: center">
			<tr>
				<th>Orderno</th>
				<th>Order date</th>
				<th>Order Status</th>
			</tr>
	

			<?php
		while($row=$result->fetch_assoc())
		{
			$orderno=$row['orderno'];
			$orderdate=$row['orderdate'];
			$status=$row['status'];
			
			echo "<tr>
					<td><pre>$orderno</pre></td>
					<td>$orderdate</td>
					<td>$status</td>
					
				</tr>";
		

		}
		?>	</table></center><?php
	}
}
function updateStatus($date,$orderno)
	{
		$servername = "localhost";
		$username = "root";
		$password = "";
		$dbname = "loginsystem";
		// Create connection
		$conn = new mysqli($servername, $username, $password, $dbname);
		$dpid=$_SESSION['d_pid'];
		
		$sql="select orderdate,orderno,status from orders where deliverypid='$dpid' and orderdate='$date' and orderno='$orderno'";

		$result=mysqli_query($conn,$sql);
		$resultCheck = mysqli_num_rows($result);?>
		<center style='font-size:30px;font-style:italic'><?php
		if($resultCheck<1)
			echo "<br>Invalid Order Number";
		else{
			?>
		<br>
		
		<table  width="500px" height="150px" border="2px" cellpadding="20px" cellspacing="5px" style="background-color: white;text-align: center;">
			<tr>
				<th>Orderno</th>
				<th>Order date</th>
				<th>Order Status</th>
			</tr>
	

			<?php
		while($row=$result->fetch_assoc())
		{
			$orderno=$row['orderno'];
			$orderdate=$row['orderdate'];
			echo "<tr>
					<td>$orderno</td>
					<td>$orderdate</td>
					<form action='includes/deliveryupdate.inc.php' method='POST'>
					<td>
					<select name='status'>
					<option value='In Progress'>In Progress</option>
					<option value='Delivered'>Delivered</option>
					<option value='Not Delivered'>Not Delivered</option>
					</select>
					<button type='submit' name='update' value='$orderno'>Update</button>	</form>
					</td>
					</tr>";
	

		}
		?>	</table></center><?php
	}
}
	if (isset($_POST['1'])) {
		?><section class="main-container">
	<div class="main-wrapper">
		<h2>Work Status</h2><br>
	</div>
	</section><?php
		$today = date('Y-m-d');
		vieworders($today,1);
		
		
	}
	elseif (isset($_POST['2'])) {
		?><section class="main-container">
	<div class="main-wrapper">
		<h2>Orders of the day</h2><br>
	</div>
	</section><?php
		$today = date('Y-m-d');
		vieworders($today,2);
		
	}
	elseif (isset($_POST['3'])) {
			?><section class="main-container">
	<div class="main-wrapper">
		<h2>Update status</h2><br>
	</div>
	</section><?php
			$today = date('Y-m-d');
			$orderno=$_POST['orderno'];
			updateStatus($today,$orderno);
		}
	
	
	?>
	<form class="signup-form" action="delivery.php" method="POST">
	<button type="submit" name="back" >Back</button></form>


<?php
	include_once 'footer.php'; /*to include footer code here*/
?>
