<?php
	include_once 'header.php';
?>
<section class="main-container">
	<div class="main-wrapper">
		<h2 style="text-align: center;">Signup</h2>
		<form class="signup-form" action="includes/signup.inc.php" method="POST">
			<input type="text" name="first" placeholder="firstname">
			<input type="text" name="last" placeholder="lastname">
			<input type="text" name="email" placeholder="E-mail">
			<input type="text" name="uid" placeholder="userid">
			<input type="password" name="pwd" placeholder="password">
			<input type="text" name="phno" placeholder="phone number">
			<textarea name="address" rows="6" cols="53" placeholder="address"></textarea>
			<button type="submit" name="submit">Signup</button>
		</form>
	</div>
</section>
<?php
	include_once 'footer.php';
?>
