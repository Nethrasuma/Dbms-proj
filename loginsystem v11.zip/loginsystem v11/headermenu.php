<?php
	/*start the session to use session variable*/
	session_start();
?>


<!-- it is a common header page-->

<!DOCTYPE html>
<html>
<head>
	<title>header</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<header>
	<nav>
		<div class="main-wrapper">
			<ul>
				<li>
					<?php
					if(isset($_SESSION['u_uid']))
					{
						$value=$_SESSION['u_uid'];

						echo "<a href='#'> $value </a>";
					}
					else
					{
						echo '<a href="index.php">Home</a>';

					}
					?>
					
				</li>
			</ul>
			<div class="nav-login">
				<?php
					if(isset($_SESSION['u_id'])){
					echo '<form action="search.php" method="POST">
						
						<input type = "text" name="food" placeholder="Enter food name">
						
						<button type="submit" name="search">Search</button>
						</form>'
						;

						echo '<form action="order.php" method="POST">
						<button type="submit" name="cart" >ViewCart</button></form>';

						echo '<form action="includes/logout.inc.php" method="POST">
						<button type="submit" name="submit">Logout</button>
						</form>'
						;

				}
				else {
					echo '<form action="includes/login.inc.php" method="POST">
						<input type="text" name="uid" placeholder="username or email">
						<input type="password" name="pwd" placeholder="password">
						<button type="submit" name="submit">Login</button>
						</form>
						
				 		<a href="signup.php">Signup</a>';


				}

				?>
			</div>
		</div>
	</nav>
</header>