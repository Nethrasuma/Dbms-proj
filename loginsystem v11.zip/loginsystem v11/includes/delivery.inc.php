<?php

/*start the session to use session variable*/
session_start();
if (isset($_POST['submit'])) {
	include_once 'dbh.inc.php';
	$deliverypid = mysqli_real_escape_string($conn, $_POST['deliverypid']) ;
	$deliverypname= mysqli_real_escape_string($conn, $_POST['deliverypname']) ;

	//error handlers
	//check if the input are empty
	if (empty($deliverypid) || empty($deliverypname)) {
		header("Location: ../delivery.php?login=empty");
		exit();
		
	}else {
		$sql = "SELECT * FROM delivery WHERE deliverypname='$deliverypname'";
		$result = mysqli_query($conn, $sql);

		$resultCheck = mysqli_num_rows($result);
		if ($resultCheck<1) {

			header("Location: ../delivery.php?login=error");
			exit();
			
		}
		else{
			if ($row = mysqli_fetch_assoc($result)) {
				//de-hashing the password
				/*to compare the password  entered in login page  with hashed password stored in database (dehash the hashed password and then compare it)*/ 
				
				if ($row['deliverypid']!=$deliverypid) {
					//if password don't match
					header("Location: ../delivery.php?login=error");
					exit();

					# code...
				}
				else
				{
					//log in the user here
					//to super global inside the php simple a variable that we can access in inside the website as along as session going inside the web page
					$_SESSION['d_pid']= $row['deliverypid'];
					$_SESSION['d_pname']= $row['deliverypname'];
					
					header("Location: ../delivery.php?login=success");
					exit();
				}
			}
		}

	}
}
else{
	header("Location: ../delivery.php?login=error");
	exit();

}


