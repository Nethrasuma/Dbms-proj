<?php
	include_once 'headeradmin.php';

	$servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "loginsystem";

	// Create connection
	$conn = new mysqli($servername, $username, $password, $dbname);
	function vieworders($date)
	{
		$servername = "localhost";
		$username = "root";
		$password = "";
		$dbname = "loginsystem";
		// Create connection
		$conn = new mysqli($servername, $username, $password, $dbname);
		
		$sql="select * from orders where orderdate='$date'";
		$result=mysqli_query($conn,$sql);
		$resultCheck = mysqli_num_rows($result);
				?><center style='font-size:30px;font-style:italic'><?php
		if($resultCheck<1)
			echo "<br> No Orders";
		else{
			?>
		<br>

			<table width="700px" height="150px" border="2px" cellpadding="20px" cellspacing="5px" style="background-color: white;text-align: 
			center">
			<tr>
				<th>Orderno</th>
				<th>Userid</th>
				<th>Delivery Person Id</th>
				<th>Delivery Status</th>
			</tr>
	

			<?php
		while($row=$result->fetch_assoc())
		{
			$orderno=$row['orderno'];
			$userid=$row['user_id'];
			$deliverypid=$row['deliverypid'];
			$status=$row['status'];
			echo "<tr>
					<td><pre>$orderno</pre></td>
					<td>$userid</td>
					<td>$deliverypid</td>
					<td>$status</td>
				</tr>";
	

		}
		?>	</table></center>
<?php
	}
}
	if (isset($_POST['1'])) {
		?><section class="main-container">
	<div class="main-wrapper">
		<h2>Orders of the day</h2><br>
	</div>
	</section><?php
		$today = date('Y-m-d');
	
			vieworders($today);
		
		
	}
	elseif (isset($_POST['2'])) {
		$particulardate=$_POST['date'];
	?><section class="main-container">
	<div class="main-wrapper">
		<h2><?php echo "Orders of $particulardate";?>
		</h2><br>
	</div>
	</section><?php
		vieworders($particulardate);
	}
	elseif (isset($_POST['3'])) {
			$sql = "(select user_id,count(orderno)  from orders group by(user_id)) UNION (SELECT u.user_id,'0' from users u where user_id not in (select user_id from orders));";
			$result=mysqli_query($conn,$sql);
			$resultCheck = mysqli_num_rows($result);
			?>
			<section class="main-container">
	<div class="main-wrapper">
		<h2>Users and thier orders</h2><br>
	</div>
	</section>
			<br>
			<center style='font-size:30px;font-style:italic'>
		<table width="500px" height="150px" border="2px" cellpadding="20px" cellspacing="5px" style="background-color: white;text-align: center">
			<tr>
				<th>Userid</th>
				<th>NO Of Orders</th>
			</tr>
	

			<?php
		while($row=$result->fetch_assoc())
		{
			$count=$row['count(orderno)'];
			$userid=$row['user_id'];
			echo "<tr>
					<td>$userid</td>
					<td>$count</td>
				</tr>";
		

		}?>	</table>
<?php
		echo "<br>No. of users $resultCheck</center>";


	}
	?>
	<form class="signup-form" action="admin.php" method="POST">
	<button type="submit" name="back" >Back</button></form>


<?php
	include_once 'footer.php'; /*to include footer code here*/
?>
