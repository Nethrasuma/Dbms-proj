
<!-- saved from url=(0022)http://www.browxy.com/ -->
<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
		<title>Java Online Compiler &amp; Runner</title>
		<meta name="keywords" content="java compiler online, java compiler, online java compiler, applet compiler, java runner, java launcher, online java ide, java ide online, java program builder, online java publisher">
		<meta name="description" content="Java Online Compiler IDE and Launcher for console programs and applets">
		<meta name="google-site-verification" content="rYbOKKXJS7BdeI0-Vb1_rEAsp8xp6b9I04_rMKnbu8o">
		<script type="text/javascript" async="" src="./Demo_files/dc.js.download"></script><script type="text/javascript" src="./Demo_files/base.js.download"></script>
		<script>
		setUIType("standard");
		</script>
		<script type="text/javascript">
		 var _gaq = _gaq || [];
		 _gaq.push(['_setAccount', 'UA-20917170-1']);
		 _gaq.push(['_setDomainName', 'browxy.com']);
		 _gaq.push(['_trackPageview']);
		 (function() {
		 var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
		 ga.src = ('https:' == document.location.protocol ? 'https://' : 'http://') + 'stats.g.doubleclick.net/dc.js';
		 var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
		 })();
		</script>
		<link rel="stylesheet" type="text/css" href="./Demo_files/main.css">
	<script type="text/javascript" src="./Demo_files/en.js.download" charset="UTF-8"></script><script type="text/javascript" src="./Demo_files/java.js.download" charset="UTF-8"></script><script type="text/javascript" src="./Demo_files/elements_functions.js.download" charset="UTF-8"></script><script type="text/javascript" src="./Demo_files/resize_area.js.download" charset="UTF-8"></script><script type="text/javascript" src="./Demo_files/reg_syntax.js.download" charset="UTF-8"></script></head>
	<body style="height: 90%;">
		<div class="header">
			<table border="0" cellpadding="0" cellspacing="0" width="100%">
				<tbody><tr>
					<td width="50%" align="left"><font class="logo">Browxy</font>&nbsp;<img src="./Demo_files/beta_icon.gif"></td>
					<td width="50%" align="right">
						<a id="homeLink" href="http://www.browxy.com/home" class="headerLink" target="rightNavigation">Home</a>&nbsp;&nbsp;
						<a id="feedbackLink" href="http://www.browxy.com/feedback" class="headerLink" target="rightNavigation">Feedback</a>&nbsp;&nbsp;
			 			<a id="submissionsLink" href="http://www.browxy.com/showSubmissions" class="headerLink" target="rightNavigation">Submissions</a>&nbsp;&nbsp;
			 			<a id="publishedCodeLink" href="http://www.browxy.com/showPublishedCode" class="headerLink" target="rightNavigation">Published Code</a>&nbsp;&nbsp;
						<a id="signInLink" href="http://www.browxy.com/userArea" class="headerLink" target="rightNavigation">SignIn</a>&nbsp;&nbsp;
			 			<a id="registerLink" href="http://www.browxy.com/registration" class="headerLink" target="rightNavigation">Register</a>&nbsp;&nbsp;
			 			<a id="termsLink" href="http://www.browxy.com/terms" class="headerLink" target="rightNavigation">Terms</a>&nbsp;&nbsp;
			 			<a id="helpLink" href="http://www.browxy.com/help" class="headerLink" target="rightNavigation">Help</a>&nbsp;&nbsp;
					</td>
				</tr>
			</tbody></table>
		</div>
		<table border="0" width="100%" height="100%" margin="0" cellspacing="0" cellpadding="0">
			<tbody><tr valign="top">
				<td width="70%">
		  			

<script type="text/javascript" src="./Demo_files/diff_match_patch.js.download"></script>
<script type="text/javascript" src="./Demo_files/ajax.js.download"></script>
<script type="text/javascript" src="./Demo_files/engine.js.download"> </script>
<script type="text/javascript" src="./Demo_files/JavaCompilerService.js.download"> </script>
<script type="text/javascript" src="./Demo_files/util.js.download"> </script>
<script type="text/javascript" src="./Demo_files/json2.js.download"></script>
<script type="text/javascript" src="./Demo_files/compiler.js.download"></script>
<script type="text/javascript" src="./Demo_files/stacktrace.js.download"></script>
<script type="text/javascript" src="./Demo_files/edit_area_loader.js.download"></script>
<link rel="STYLESHEET" type="text/css" href="./Demo_files/generic.css">
<link rel="STYLESHEET" type="text/css" href="./Demo_files/tabber.css">
<script type="text/javascript" src="./Demo_files/popup.js.download"></script>
<link rel="STYLESHEET" type="text/css" href="./Demo_files/popup.css">

<script>
function openDefaultFile() {
    var codeType = "";
    var id = "0"; 
    if (codeType != null && id != 0) {
        getCode (codeType, id, function (result) {
            code = JSON.parse(result);
            showCode (code.codeType, code.id, code.name, code.sourceCode); 
        });       
    } else {
        newFile();
    }
}
</script>

<script type="text/javascript">
var sessionId;
var lastUserText = "";
var appletConsoleEnabled = true;
	editAreaLoader.init({
		id: "code"
		,start_highlight: true
		,allow_toggle: false
		,language: "en"
		,syntax: "java"
		,toolbar: "search, go_to_line, |, undo, redo, |, select_font"
		,syntax_selection_allow: "java"
		,is_multi_files: true
		,show_line_colors: true
		,allow_resize : false
		,EA_load_callback: "openDefaultFile"
	});
</script>
<table id="compilerTable" width="100%" height="100%" class="sample">
	<tbody><tr height="1%">
		<td colspan="2" bgcolor="silver">
			<span class="firstrow">
				<table class="verticalAlign" width="100%">
					<tbody><tr>
						<td><select id="exampleCombo" class="defaultSelect"><option value="1">Hello World !</option><option value="2">Animal Game</option><option value="3">Thread Example</option><option value="4">Car Loan Applet</option><option value="5">Random Dots</option><option value="6">Plasma Fractal</option></select></td>
						<td><input id="tryExampleButton" class="buttonExample" type="button" value="Try" onclick="javascript:openExampleCodeBySelectedComboId();"></td>
						<td style="width:300px">&nbsp;</td>
						<td><div class="menuText">Args</div></td>
						<td><input id="args" name="args" type="text" value="" style="width:100px"></td>
						<td><input id="startButton" type="button" class="button" value="Start" onclick="run()"></td>
						<td><input id="stopButton" class="button" type="button" value="Stop" onclick="stop()"></td>
						<td><input id="status" name="status" class="statusBox" type="text" value="Not Running"></td>
						<td>&nbsp;&nbsp;</td>
					</tr>
				</tbody></table>
			</span>
		</td>
	</tr>
	<tr class="silver">
		<td bgcolor="gray" width="20%" align="center"><select class="defaultSelect" id="saveCombo"><option value="-2">File - Login to enable</option></select></td>
		<td bgcolor="gray" class="silver">
				<input id="refreshSavedComboButton" class="button" type="button" value="Refresh" onclick="javascript:refreshSavedCodeCombo();"> 
				<input id="openCodeButton" class="button" type="button" value="Open" onclick="javascript:openCode();"> 
				<input id="newFileButton" class="button" type="button" value="New" onclick="javascript:newFile();"> 
				<input id="saveFileButton" class="button" type="button" value="Save" onclick="javascript:saveSelectedFile();"> 
				<input id="downloadFileButton" class="button" type="button" value="Download" onclick="javascript:download();">
				<input id="renameFileButton" class="button" type="button" value="Rename" onclick="javascript:rename();">
				<input id="deleteFileButton" class="button" type="button" value="Delete" onclick="javascript:remove();">
				<input id="getUrlButton" class="button" type="button" value="GetUrl" onclick="javascript:getUrl();">
				<input id="publishButton" class="publishButton" type="button" value="Publish" onclick="javascript:publish();">
		</td>
	</tr>
	<tr height="50%">
		<td colspan="2"><textarea id="code" class="result" name="code" style="display: none;"></textarea><iframe name="frame_code" id="frame_code" frameborder="0" style="border-width: 0px; overflow: hidden; display: inline; width: 1075px; height: 337px;" src="./Demo_files/saved_resource.html"></iframe></td>
	</tr>
	<tr height="40%">
		<td colspan="2" valign="top">
			<div id="outputTabber" width="100%" class="tabberlive" style="height:100%"><ul class="tabbernav"><li class="tabberactive"><a href="javascript:void(null);" title="Console View">Console View</a></li><li class=""><a href="javascript:void(null);" title="Applet View">Applet View</a></li><li class=""><a href="javascript:void(null);" title="Log View">Log View</a></li></ul>
			    <div id="consoleBox" class="tabbertab " title="">
				    <textarea id="chatlog" class="result" rows="8" name="result" onkeypress="javascript:handleEnter(this, event)"></textarea>
		    	</div>
		    	<div class="tabbertab tabbertabhide" title="">
			        <div id="gamebox" align="center">
			        	<textarea id="iframeContainer" class="result2" name="result"></textarea>
		        	</div>
		    	</div>
		    	<div class="tabbertab tabbertabhide" title="">
			        <textarea id="logConsole" class="result2" rows="8" name="result"></textarea>
		    	</div>
			</div>
		</td>
	</tr>
</tbody></table>

<script>
	dwr.engine.setWarningHandler(log);
	dwr.engine.setErrorHandler(customErrorHandler);
	dwr.engine.setTextHtmlHandler(log);
	fillExampleCodeList();
	refreshSavedCodeCombo();
	//document.getElementById("chatlog").style.height = document.getElementById("consoleBox").offsetHeight;
	//document.getElementById("logConsole").style.height = document.getElementById("consoleBox").offsetHeight;
	//document.getElementById("iframeContainer").style.height = document.getElementById("consoleBox").offsetHeight;
</script>  

<script type="text/javascript" src="./Demo_files/tabber.js.download"></script>

				</td>
				<td width="30%">
					<div id="rightPanel" class="pruebaDiv"><iframe class="pruebaDiv" id="rightNavigation" name="rightNavigation" src="./Demo_files/home.html"></iframe></div>
				</td>
			</tr>
		</tbody></table>
		<script>
		addLoadMessage();
		</script><div id="loadingAjaxMessage" class="loadingMessage" style="position: absolute; top: 349px; left: 718px; display: block;">Loading...</div>
	
</body></html>