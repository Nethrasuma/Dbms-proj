<?php
	include_once 'headerdelivery.php';
		if(isset($_SESSION['d_pid']))
		{
			?><center style='font-size:30px;font-style:italic'><?php
			echo '<br><pre><form action="deliveryviews.php" method="POST">1. View delivery orders	<button type="submit" name="1">View</button></form><br>';
			echo '<br><form action="deliveryviews.php" method="POST">2. View orders of the day <button type="submit" name="2">View</button></form><br>';
			echo '<br><form action="deliveryviews.php" method="POST">3. Update Status of orders <input type = "text" name="orderno" placeholder="enter orderno"> <button type="submit" name="3">View</button></form><br></pre>';
			?></center><?php
		}
?>

<?php
	include_once 'footer.php'; /*to include footer code here*/
?>