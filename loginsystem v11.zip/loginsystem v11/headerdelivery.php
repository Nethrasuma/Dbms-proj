<?php
	/*start the session to use session variable*/
	session_start();
?>


<!-- it is a common header page-->

<!DOCTYPE html>
<html>
<head>
	<title>header</title>
	<link rel="stylesheet" type="text/css" href="style.css">

</head>
<body>
<header>
	<nav>
		<div class="main-wrapper">
			<ul>
				<li>
					<?php
					if(isset($_SESSION['d_pname']))
					{
						$value=$_SESSION['d_pname'];

						echo "<a href='#'> $value </a>";
					}
					else
					{
						echo '<a href="index.php">Home</a>';

					}
					?>

					</li>
			</ul>
			<div class="nav-login">
				<?php
					if(isset($_SESSION['d_pid'])){
					echo '<form action="includes/logout.inc.php" method="POST">
						<button type="submit" name="submit">Logout</button>
						</form>';

				}
				else {
					echo '<form action="includes/delivery.inc.php" method="POST">
						<input type="text" name="deliverypname" placeholder="name">
						<input type="password" name="deliverypid" placeholder="password">
						<button type="submit" name="submit">Submit</button></form>';
				 	}

				?>
			</div>
		</div>
	</nav>
</header>

<?php
if(isset($_SESSION['d_pid'])){}
else
{
	?>
	<section class="main-container">
	<div class="main-wrapper">
		
		<h3><strong><em>"You don't need <br> a silver fork <br> to eat good food!!"</em></strong></h3>
				<div class="imagechange" >
			<img src="projectpics\deliverypagepic.png	" width="100%" height="100%" >
		</div>
		
	<!--<div class="imagechange" width="10%" height="95%">
			<img src="projectpics\admincoverpic.jpg">
		</div><-->
	</div>
</section><?php
	
}